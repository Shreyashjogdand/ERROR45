package com.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.SessionFactory;

import com.entity.User;

public class UserDao {

    private SessionFactory factory=null;
    private Session session=null;
    private Transaction tx=null;

    public UserDao(SessionFactory factory) {
        this.factory = factory;
    }

    // Save user (Registration)
    public boolean saveUser(User user) {
        boolean success = false;
        Transaction tx = null;

        try (Session session = factory.openSession()) {
            tx = session.beginTransaction();
            session.save(user);
            tx.commit();
            success = true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }

        return success;
    }

    // Login (Check user by email and password)
    public User login(String email, String password) {
        User user = null;
        try (Session session = factory.openSession()) {
            Query<User> query = session.createQuery("FROM User WHERE email = :email AND password = :password", User.class);
            query.setParameter("email", email);
            query.setParameter("password", password);
            user = query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // Get user by ID
    public User getUserById(int id) {
        User user = null;
        try (Session session = factory.openSession()) {
            user = session.get(User.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // Update user info
    public boolean updateUser(User user) {
        boolean success = false;
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            tx = session.beginTransaction();
            session.update(user);
            tx.commit();
            success = true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
        return success;
    }

    // Delete user
    public boolean deleteUser(int id) {
        boolean success = false;
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            User user = session.get(User.class, id);
            if (user != null) {
                tx = session.beginTransaction();
                session.delete(user);
                tx.commit();
                success = true;
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
        return success;
    }
    
 // Login (Check user by email and password)
    public User login1(String email, String password) {
        User user = null;
         session = factory.openSession();
            Query query = session.createQuery("FROM User WHERE email = :email AND password = :password");
            query.setParameter("email", email);
            query.setParameter("password", password);
            user = (User) query.uniqueResult();
       
        return user;
    }

    // Get user by ID
 /* public User getUserById(int id) {
        User user = null;
        try (Session session = factory.openSession()) {
            user = session.get(User.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // Update user info
   /* public boolean updateUser(User user) {
        boolean success = false;
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            tx = session.beginTransaction();
            session.update(user);
            tx.commit();
            success = true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
        return success;
    }

    // Delete user
    public boolean deleteUser(int id) {
        boolean success = false;
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            User user = session.get(User.class, id);
            if (user != null) {
                tx = session.beginTransaction();
                session.delete(user);
                tx.commit();
                success = true;
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
        return success;
    }*/
}
