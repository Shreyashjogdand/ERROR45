package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Expense;
import com.entity.User;

public class ExpenseDao {

    private SessionFactory factory;

    public ExpenseDao(SessionFactory factory) {
    	super();
        this.factory = factory;
    }

    // Save expense
    public boolean saveExpense(Expense expense) {
    	boolean success = false;
        Transaction tx = null;
        
        try (Session session = factory.openSession()) {
            tx = session.beginTransaction();
            session.save(expense);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Get all expenses for a user
    public List<Expense> getAllExpensesByUser(User user) {
        try (Session session = factory.openSession()) {
            return session
                .createQuery("from Expense where user = :uid order by id desc", Expense.class)
                .setParameter("uid", user)
                .list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Get single expense by ID
    public Expense getExpenseById(int id) {
        try (Session session = factory.openSession()) {
            return session.get(Expense.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Update expense
    public boolean updateExpense(Expense expense) {
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            tx = session.beginTransaction();
            session.update(expense);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }

    // Delete expense
    public boolean deleteExpense(int id) {
        Transaction tx = null;
        try (Session session = factory.openSession()) {
            Expense exp = session.get(Expense.class, id);
            if (exp != null) {
                tx = session.beginTransaction();
                session.delete(exp);
                tx.commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }
}
