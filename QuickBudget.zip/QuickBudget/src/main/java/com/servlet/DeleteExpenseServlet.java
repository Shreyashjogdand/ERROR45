package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.ExpenseDao;
import com.db.HibernateUtil;

@WebServlet("/deleteExpense")
public class DeleteExpenseServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            ExpenseDao dao = new ExpenseDao(HibernateUtil.getSessionFactory());
            boolean deleted = dao.deleteExpense(id);
            
            HttpSession session = request.getSession();
            if (deleted) {
                session.setAttribute("msg", "Expense deleted successfully.");
            } else {
                session.setAttribute("msg", "Failed to delete expense.");
            }

            response.sendRedirect("user/view_expense.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp"); // Optional: create an error page
        }
    }
}
